package io.openfactory.api.workpack;

import io.openfactory.api.workpack.model.Workpack;
import io.openfactory.api.workpack.model.WorkpackStage;
import io.openfactory.core.brief.model.IdeaBrief;
import io.openfactory.core.handoff.HandoffService;
import io.openfactory.core.handoff.model.HandoffPackage;
import io.openfactory.core.plan.model.ExecutionPlan;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class WorkpackService {

    @Inject
    HandoffService coreHandoffService;

    @Inject
    WorkpackMapper mapper;

    // -----------------------------------------------------------------------
    // Create
    // -----------------------------------------------------------------------

    @Transactional
    public Workpack createFromPipeline(String title, UUID ownerId,
                                        IdeaBrief brief, ExecutionPlan plan) {
        HandoffPackage handoff = coreHandoffService.create(
            brief.projectId(), brief, plan);
        return mapper.toEntity(title, ownerId, handoff, plan);
    }

    // -----------------------------------------------------------------------
    // Read
    // -----------------------------------------------------------------------

    public Workpack findById(UUID id) {
        Workpack w = Workpack.findById(id);
        if (w == null) throw new NotFoundException("Workpack not found: " + id);
        return w;
    }

    public List<Workpack> listAll() {
        return Workpack.listAll();
    }

    public List<Workpack> listByOwner(UUID ownerId) {
        return Workpack.findByOwner(ownerId);
    }

    public ExecutionPlan getExecutionPlan(UUID id) {
        Workpack w = findById(id);
        ExecutionPlan plan = mapper.toPlan(w);
        if (plan == null)
            throw new NotFoundException("No execution plan for workpack: " + id);
        return plan;
    }

    public List<StepSummary> getStepSummaries(UUID id) {
        return getExecutionPlan(id).steps().stream()
            .map(s -> new StepSummary(s.stepId(), s.boxId(), s.boxTitle(),
                                      s.order(), s.parallel(), s.requiresApproval()))
            .toList();
    }

    // -----------------------------------------------------------------------
    // Stage transitions
    // -----------------------------------------------------------------------

    @Transactional
    public Workpack advanceStage(UUID id) {
        Workpack w = findById(id);
        w.stage = switch (w.stage) {
            case RAW    -> WorkpackStage.DEFINE;
            case DEFINE -> WorkpackStage.SHAPE;
            case SHAPE  -> WorkpackStage.BOX;
            case BOX    -> throw new IllegalStateException(
                "Workpack " + id + " is already at BOX stage.");
        };
        w.persist();
        return w;
    }

    @Transactional
    public Workpack updateTitle(UUID id, String title) {
        Workpack w = findById(id);
        w.title = title;
        w.persist();
        return w;
    }

    // -----------------------------------------------------------------------
    // Value types
    // -----------------------------------------------------------------------

    public record StepSummary(
        String stepId,
        String boxId,
        String boxTitle,
        int order,
        boolean parallel,
        boolean requiresApproval
    ) {}
}
