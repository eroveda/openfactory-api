package io.openfactory.api.workpack;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.openfactory.api.user.model.User;
import io.openfactory.api.workpack.model.Workpack;
import io.openfactory.core.handoff.model.HandoffPackage;
import io.openfactory.core.plan.model.ExecutionPlan;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.util.UUID;

@ApplicationScoped
public class WorkpackMapper {

    @Inject
    ObjectMapper objectMapper;

    @Transactional
    public Workpack toEntity(String title, UUID ownerId,
                              HandoffPackage handoff, ExecutionPlan plan) {
        Workpack w = new Workpack();
        w.title = title;
        w.owner = User.findById(ownerId);
        if (plan != null) {
            w.executionPlan = serializePlan(plan);
            w.stepCount     = plan.steps().size();
        }
        w.persist();
        return w;
    }

    public ExecutionPlan toPlan(Workpack w) {
        if (w.executionPlan == null || w.executionPlan.isBlank()) return null;
        try {
            return objectMapper.readValue(w.executionPlan, ExecutionPlan.class);
        } catch (JsonProcessingException e) {
            throw new WorkpackMappingException(
                "Failed to deserialize ExecutionPlan for workpack " + w.id, e);
        }
    }

    private String serializePlan(ExecutionPlan plan) {
        try {
            return objectMapper.writeValueAsString(plan);
        } catch (JsonProcessingException e) {
            throw new WorkpackMappingException(
                "Failed to serialize ExecutionPlan for project " + plan.projectId(), e);
        }
    }
}
